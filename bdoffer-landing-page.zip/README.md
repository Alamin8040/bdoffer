# BDOFFER Landing Page

এই ফোল্ডারে GitHub Pages-এর জন্য ৩টি মূল ফাইল আছে:

- `index.html`
- `style.css`
- `script.js`

## সবচেয়ে গুরুত্বপূর্ণ পরিবর্তন

`script.js` খুলে:

1. `WHATSAPP_NUMBER`-এ আপনার WhatsApp নম্বর দিন।
2. `offers` তালিকায় আপনার আসল অফারের নাম, GB, মেয়াদ, দাম ও link দিন।
3. `link` ফাঁকা থাকলে কাস্টমার WhatsApp-এ অর্ডার করতে পারবে।
4. `link`-এ URL দিলে কাস্টমার সেই URL-এ যাবে।

GitHub Pages static HTML/CSS/JS চালায়। তাই সরাসরি PHP/backend checkout এখানে চলবে না। Automated payment চাইলে আলাদা payment/order service বা API লাগবে.
