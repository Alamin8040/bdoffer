/*
  ============================================
  BDOFFER OFFER LIST
  ============================================
  1) WHATSAPP_NUMBER-এ আপনার WhatsApp নম্বর দিন।
     উদাহরণ: 8801712345678
  2) প্রতিটি offer-এর link ফাঁকা রাখলে WhatsApp order খুলবে।
  3) চাইলে link-এ আপনার payment/order URL বসাতে পারবেন।
*/

const WHATSAPP_NUMBER = "8801XXXXXXXXX";

const offers = [
  {op:"BL", name:"Banglalink", type:"ইন্টারনেট", amount:"25 GB", days:"30 দিন", price:"৳299", link:""},
  {op:"GP", name:"Grameenphone", type:"ইন্টারনেট", amount:"25 GB", days:"30 দিন", price:"৳299", link:""},
  {op:"Robi", name:"Robi", type:"ইন্টারনেট", amount:"25 GB", days:"30 দিন", price:"৳299", link:""},
  {op:"Airtel", name:"Airtel", type:"ইন্টারনেট", amount:"25 GB", days:"30 দিন", price:"৳299", link:""},

  {op:"BL", name:"Banglalink", type:"ইন্টারনেট", amount:"20 GB", days:"30 দিন", price:"৳249", link:""},
  {op:"GP", name:"Grameenphone", type:"ইন্টারনেট", amount:"20 GB", days:"30 দিন", price:"৳249", link:""},
  {op:"Robi", name:"Robi", type:"ইন্টারনেট", amount:"20 GB", days:"30 দিন", price:"৳249", link:""},
  {op:"Airtel", name:"Airtel", type:"ইন্টারনেট", amount:"20 GB", days:"30 দিন", price:"৳249", link:""},

  {op:"BL", name:"Banglalink", type:"ইন্টারনেট", amount:"15 GB", days:"30 দিন", price:"৳199", link:""},
  {op:"GP", name:"Grameenphone", type:"ইন্টারনেট", amount:"15 GB", days:"30 দিন", price:"৳199", link:""},
  {op:"Robi", name:"Robi", type:"ইন্টারনেট", amount:"15 GB", days:"30 দিন", price:"৳199", link:""},
  {op:"Airtel", name:"Airtel", type:"ইন্টারনেট", amount:"15 GB", days:"30 দিন", price:"৳199", link:""},

  {op:"BL", name:"Banglalink", type:"ইন্টারনেট", amount:"10 GB", days:"15 দিন", price:"৳149", link:""},
  {op:"GP", name:"Grameenphone", type:"ইন্টারনেট", amount:"10 GB", days:"15 দিন", price:"৳149", link:""},
  {op:"Robi", name:"Robi", type:"ইন্টারনেট", amount:"10 GB", days:"15 দিন", price:"৳149", link:""},
  {op:"Airtel", name:"Airtel", type:"ইন্টারনেট", amount:"10 GB", days:"15 দিন", price:"৳149", link:""},

  {op:"BL", name:"Banglalink", type:"মিনিট", amount:"500 মিনিট", days:"30 দিন", price:"৳199", link:""},
  {op:"GP", name:"Grameenphone", type:"মিনিট", amount:"500 মিনিট", days:"30 দিন", price:"৳199", link:""},
  {op:"Robi", name:"Robi", type:"মিনিট", amount:"500 মিনিট", days:"30 দিন", price:"৳199", link:""},
  {op:"Airtel", name:"Airtel", type:"মিনিট", amount:"500 মিনিট", days:"30 দিন", price:"৳199", link:""},

  {op:"BL", name:"Banglalink", type:"বান্ডেল", amount:"10 GB + 300 মিনিট", days:"30 দিন", price:"৳299", link:""},
  {op:"GP", name:"Grameenphone", type:"বান্ডেল", amount:"10 GB + 300 মিনিট", days:"30 দিন", price:"৳299", link:""},
  {op:"Robi", name:"Robi", type:"বান্ডেল", amount:"10 GB + 300 মিনিট", days:"30 দিন", price:"৳299", link:""},
  {op:"Airtel", name:"Airtel", type:"বান্ডেল", amount:"10 GB + 300 মিনিট", days:"30 দিন", price:"৳299", link:""},
  {op:"BL", name:"Banglalink", type:"ইন্টারনেট", amount:"50 GB", days:"30 দিন", price:"৳499", link:""}
];

const grid = document.getElementById("offerGrid");
const count = document.getElementById("count");

function render(filter = "all") {
  const list = filter === "all" ? offers : offers.filter(x => x.op === filter);
  count.textContent = `${list.length}টি অফার`;

  grid.innerHTML = list.map((o, i) => `
    <article class="offer-card">
      <div class="offer-top">
        <span class="tag">${o.type}</span>
        <span class="operator-name">${o.name}</span>
      </div>
      <h3>${o.amount}</h3>
      <div class="details">মেয়াদ: ${o.days}</div>
      <div class="price">${o.price}</div>
      <button class="buy" onclick="buyOffer(${offers.indexOf(o)})">কিনুন <span>→</span></button>
    </article>
  `).join("");
}

function buyOffer(index) {
  const o = offers[index];

  if (o.link && o.link.trim() !== "") {
    window.open(o.link, "_blank");
    return;
  }

  const msg = `আসসালামু আলাইকুম। আমি এই অফারটি কিনতে চাই:%0A%0Aঅপারেটর: ${o.name}%0Aঅফার: ${o.amount}%0Aমেয়াদ: ${o.days}%0Aমূল্য: ${o.price}`;
  if (!WHATSAPP_NUMBER.includes("X")) {
    window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${msg}`, "_blank");
  } else {
    alert("প্রথমে script.js ফাইলে WHATSAPP_NUMBER-এ আপনার WhatsApp নম্বর দিন।");
  }
}

document.querySelectorAll(".operator-card").forEach(btn => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".operator-card").forEach(x => x.classList.remove("active"));
    btn.classList.add("active");
    render(btn.dataset.filter);
    document.getElementById("offers").scrollIntoView({behavior:"smooth", block:"start"});
  });
});

document.getElementById("year").textContent = new Date().getFullYear();
render();
